﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio1
{
    internal class Producto
    {
        //atributos
        string name { get; set; }
        decimal precie { get; set; }
        char description { get; set; }

        /// <summary>
        /// Un pedido Contine muchos productor
        /// un producto  puede estar un muchos pedidos 
        /// N:M
        /// </summary>
        internal Pedido Pedido
        {
            get => default;
            set
            {
            }
        }

        //constructor
        //funciones
        //get
        public string GetName()
        {
            return name;
        }
        public decimal GetPrecie()
        {
            return precie;
        }
        //set
        public void SetName(string name)
        {
            if (!String.IsNullOrEmpty(name))
            {
                this.name = name;
            }
            else this.name = "Desconosido";
        }
        public void SetPrecie(decimal precie)
        {
            if(precie > 0)
            {
                this.precie = precie;
            }
            else
            {
                precie = -1;
            }
        }
        public void SetDescription(char des)
        {
            switch (des)
            {
                case 'b': this.description=des; break;
                case 'c': this.description = des; break;
                case 'o': this.description = des; break;
            }
            if (description == ' ') description= 'o';
        }

        //other


        public override string ToString()
        {
            string des = "";
            switch (description)
            {
                case 'b': des = "Bebidas"; break;
                case 'c': des = "Cominda"; break;
                case 'o': des = "otros"; break;
            }

                string salida = $"||    {des}    || {name}: {precie}";
            return salida;
        }
    }
}
