﻿
namespace Ejercicio1
{

    internal class Program
    {
        //El pedido puede tner cualquier numero de productos 
        //maximo 5 pedidos 
        //menu todo en uno añadir pedido, mostrar productos , sacar pedido  
        // pedido listra productos y fecha (dia mes año y hora)
        //mostrar coste de los pedidos
        //hacer caja mostrar todo los pedidos y el total de dinero recaudado 
        private static void Main(string[] args)
        {
            string path = "..\\\\..\\\\..\\\\menu.txt"; // ruta para cargar el menu 
            List<Pedido> ordersInLine = new List<Pedido>(); //pedidos realizandose
            List<Pedido> ordersResolved = new List<Pedido>();// pedidos resueltos 
            List<Producto> productsList = FuncionesCafeteria.CreateListProdoc(path); // lista de productos
            List<int> listIntOrders= new List<int>(); //lista para saber los numeros del pedidod 
            const int ORDERSIZE = 5; // maximo de pedidos
            int entrada = 0; // dato de paso
            //totales para los diferentes campos 
            int totalPedidosInLine=0; // actuales en solicitud
            int totalPedidosResolved=0; // totales resueltos 
            decimal totalRecaudado = 0; 
           if(productsList.Count>0)
            {

                do
                {
                    //-> menu
                    FuncionesCafeteria.MostrarMenus();
                    switch (entrada = FuncionesCafeteria.EntradaIntMenu())
                    {
                        //-> Regitra pedido
                        case 1:
                            Console.WriteLine("-Hacer pedidio-");
                            if (totalPedidosInLine <= ORDERSIZE)
                            {
                                FuncionesCafeteria.SearchCard(productsList);// muestra el menu 
                                                                            //sacar los productos del pedidodo 
                                Console.WriteLine("Escriba el numero de los productos que desee");
                                Console.WriteLine("0 para salir");
                                listIntOrders = FuncionesCafeteria.CreateListOrder(productsList);// crea la lista de pedidos 
                                ordersInLine.Add(new Pedido());
                                //cada int-1= posision en lista de producto => agrega a la lista de pedididos ese producto
                                //                                             a la del pediddo.

                                listIntOrders.ForEach(i => ordersInLine[totalPedidosInLine].AddProducAt(productsList[i - 1]));
                                ordersInLine[totalPedidosInLine].SetdateTime(DateTime.Now);
                                //comprobacion
                                ordersInLine[totalPedidosInLine].GetProductos().ForEach(produc => Console.WriteLine(produc.GetName()));
                                totalPedidosInLine++;
                            }
                            else Console.WriteLine("no se puede ingresar mas pedidos");
                            //--------bloqueo y mensajes antes de hacer clear
                            Console.ForegroundColor = ConsoleColor.Magenta;
                            Console.WriteLine("pulse una tacla para finalizar");
                            Console.ForegroundColor = ConsoleColor.White;
                            Console.ReadKey();
                            break;
                        //-> resolver orden
                        case 2:
                            if (ordersInLine.Count > 0)
                            {
                                //copiar un elemento en otro lista y desaparecerlo del anterior
                                ordersResolved.Add(new Pedido());
                                ordersResolved[totalPedidosResolved].SetProductos(ordersInLine[0].GetProductos());
                                ordersResolved[totalPedidosResolved].SetdateTime(ordersInLine[0].GetDateTime());
                                ordersResolved[totalPedidosResolved].RecalTotal(); // obliga a recalcular el total 
                                ordersInLine.RemoveAt(0);
                                //suma el total del pedido a totalRecaudado
                                totalRecaudado += ordersResolved[totalPedidosResolved].GetTotal();
                                totalPedidosResolved++;
                                totalPedidosInLine--;
                                Console.WriteLine("pedido resuelto correctamente");
                            }
                            else Console.WriteLine("no hay pedidos para resolver");
                            //--------bloqueo y mensajes antes de hacer clear
                            Console.ForegroundColor = ConsoleColor.Magenta;
                            Console.WriteLine("pulse una tacla para finalizar");
                            Console.ForegroundColor = ConsoleColor.White;
                            Console.ReadKey();
                            break;
                        //-> hacer caja 
                        case 3:
                            if (ordersResolved.Count > 0)
                            {
                                ordersResolved.ForEach(pedido => Console.WriteLine(pedido.ToString()));
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine($"El total recaudado es de  {totalRecaudado}");
                                Console.ForegroundColor = ConsoleColor.White;
                            }
                            else Console.WriteLine("no hay pedidos resueltos como para hacer caja ");
                            //--------bloqueo y mensajes antes de hacer clear
                            Console.ForegroundColor = ConsoleColor.Magenta;
                            Console.WriteLine("pulse una tacla para finalizar");
                            Console.ForegroundColor = ConsoleColor.White;
                            Console.ReadKey();
                            break;
                        case 0:
                            break;
                    }
                    Console.Clear();
                } while (entrada != 0);
            }
            else Console.WriteLine("no hay productos");
        }
    }
}
