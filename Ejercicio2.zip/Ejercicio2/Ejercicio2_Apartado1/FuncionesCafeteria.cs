﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio1
{
    internal class FuncionesCafeteria
    {
        //muestra opciones del programa
        public static void MostrarMenus()
        {
            Console.WriteLine("------------------------------");
            Console.WriteLine("1_Hacer Pedido");
            Console.WriteLine("2_Resolver pedido");
            Console.WriteLine("3_hacer caja");
            Console.WriteLine("------------------------------");
        }
        //entrada para un numero del menuc
        public static int  EntradaIntMenu()
        {
            int nun;
            Console.WriteLine("Dime una opcion");
            while (!(Int32.TryParse(Console.ReadLine(),out nun)&&nun>0&&nun<4))
            {
                Console.WriteLine("dato incorrecto");
            }
            return nun;
        }
        //muestra la carta
        public static void SearchCard(List<Producto> ProducList)
        {
            int nun=1;
            //Console.WriteLine($"{nun++} {produc.ToString()}")
            ProducList.ForEach(produc => Console.WriteLine( nun++ +"_ "+produc.ToString()));// si  son varias ordenes cambiar por un foreach normal 
        }
       // cra una lista con los numero para los pedidos 
        public static List<int> CreateListOrder(List<Producto> productosList)
        {
            List<int> list = new List<int>();
            int entrada= -1;
            do
            {
                while (!(int.TryParse(Console.ReadLine(), out entrada) && entrada >= 0 && entrada <= productosList.Count()))
                    Console.WriteLine("entrada invalidad");
                list.Add(entrada);
            } while (entrada != 0);
            list.RemoveAt(list.Count - 1);
            return list;
        }

        //crea la lista de producto ataves de un fichero 
       public static List<Producto> CreateListProdoc(string path)
        {
            List<Producto> list = new List<Producto>();
            List<string> files = new List<string>();
            char des;
            decimal prece;
            string name;
            int cont=0;
            try
            {
                //sacamos las lineas
                foreach (string line in File.ReadLines(path))
                {
                    files.Add(line);
                }
                //prosesamos las lineas 
                foreach(string file in files)
                {
                    List<string> data = file.Split(';').ToList();
                    des = data[0].ToCharArray()[0];
                    name = data[1];
                    if(!decimal.TryParse(data[2],out prece))
                    {
                         list.Clear();
                        return list;
                    }
                    list.Add(new Producto());
                    list[cont].SetPrecie(prece);
                    list[cont].SetName(name);
                    list[cont].SetDescription(des);
                    cont++;
                }
               

            }
            catch
            {
                Console.WriteLine("Fallo al cargar los productos");
            }
            return list;
        }
    }
}
