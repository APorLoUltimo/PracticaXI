﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Ejercicio1
{
    internal class Pedido
    {
        //atributos 
        List<Producto> Productos { get; set; }
        decimal total { get; set; }
        DateTime dateTime { get; set; }
        //contructor
        public Pedido()
        {
            this.Productos=new List<Producto>();
        }
        //fucniones
        //get
        public List<Producto> GetProductos()
        {
            return this.Productos; 
        }
        public decimal GetTotal()
        {
            return this.total;
        }
        public DateTime GetDateTime()
        {
            return this.dateTime;
        }
        //set
        public void SetProductos(List<Producto> productos)
        {
            if (productos.Count() > 0) this.Productos = productos;
            //else 
        }
        public void SetdateTime(DateTime dateTime)
        {
            this.dateTime = dateTime;
        }
        //other
        public void AddProducAt(Producto producto)
        {
            Productos.Add(producto);
            total += producto.GetPrecie();
        }
        public void RecalTotal()
        {
            Productos.ForEach(product =>total+=product.GetPrecie());
        }
        public override string ToString()
        {
            string salida =  "-------------------------------------------------------\n";
            salida += dateTime.ToString();
            Productos.ForEach(produc => salida += "\n " + produc.ToString() + "\n ---------------------------------");
            salida +="----------------------------------------------------------------------------------------------" ;
            return salida;
        }
    }
}
