﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ejercicio1_Apartado2
{
    public class AdvancedPlayer : Player
    {
        public void drive()
        {
            throw new System.NotImplementedException();
        }
    }
}