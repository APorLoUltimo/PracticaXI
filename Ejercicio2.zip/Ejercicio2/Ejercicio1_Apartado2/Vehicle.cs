﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ejercicio1_Apartado2
{
    public class Vehicle
    {
        private decimal maxVelocity
        {
            get => default;
            set
            {
            }
        }

        public decimal velocity
        {
            get => default;
            set
            {
            }
        }

        public AdvancedPlayer AdvancedPlayer
        {
            get => default;
            set
            {
            }
        }

        public void GetVelocity()
        {
            throw new System.NotImplementedException();
        }

        public void GetMaxVelocity()
        {
            throw new System.NotImplementedException();
        }

        public void SetVelocity()
        {
            throw new System.NotImplementedException();
        }
    }
}