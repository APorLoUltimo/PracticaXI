﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ejercicio1_Apartado2
{
    public class Player
    {
        private string username
        {
            get => default;
            set
            {
            }
        }

        private int liveAmount
        {
            get => default;
            set
            {
            }
        }

        private decimal positionX
        {
            get => default;
            set
            {
            }
        }

        private decimal positionY
        {
            get => default;
            set
            {
            }
        }

        public void GetUsername()
        {
            throw new System.NotImplementedException();
        }

        public void GetPositionX()
        {
            throw new System.NotImplementedException();
        }

        public void GetPositionY()
        {
            throw new System.NotImplementedException();
        }

        public void GetUsername()
        {
            throw new System.NotImplementedException();
        }

        public void SetPositionX()
        {
            throw new System.NotImplementedException();
        }

        public void SetPositionY()
        {
            throw new System.NotImplementedException();
        }

        public void SetUsername()
        {
            throw new System.NotImplementedException();
        }

        public void SetLiveAmount()
        {
            throw new System.NotImplementedException();
        }
    }
}