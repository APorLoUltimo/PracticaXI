﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ejercicio1_Apartado1
{
    public class Profesores : Personas
    {
        public int Asignaturas
        {
            get => default;
            set
            {
            }
        }

        public int ContadorProfesores
        {
            get => default;
            set
            {
            }
        }
    }
}