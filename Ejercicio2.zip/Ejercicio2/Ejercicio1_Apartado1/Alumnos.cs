﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ejercicio1_Apartado1
{
    public class Alumnos : Personas
    {
        public int Asignaturas
        {
            get => default;
            set
            {
            }
        }

        public int ContadorAlumnos
        {
            get => default;
            set
            {
            }
        }
    }
}