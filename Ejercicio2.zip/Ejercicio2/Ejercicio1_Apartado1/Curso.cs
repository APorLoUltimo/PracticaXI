﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ejercicio1_Apartado1
{
    public class Curso
    {
        public Profesores Profesores
        {
            get => default;
            set
            {
            }
        }

        public Alumnos Alumnos
        {
            get => default;
            set
            {
            }
        }

        public void MatricularProfesor()
        {
            throw new System.NotImplementedException();
        }

        public void MatricularAlumno()
        {
            throw new System.NotImplementedException();
        }
    }
}