﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ejercicio1_Apartado1
{
    public class Personas
    {
        public string nombre
        {
            get => default;
            set
            {
            }
        }

        public string apellidos
        {
            get => default;
            set
            {
            }
        }

        public System.DateTime fechanacimiento
        {
            get => default;
            set
            {
            }
        }
    }
}