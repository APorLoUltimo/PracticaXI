﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp1
{
    public abstract class Figura
    {

        private string color
        {
            get => default;
            set
            {
            }
        }

        public abstract void CalcularArea();
    }
}