﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp1
{
    public class Círculo : Figura
    {
        public decimal radio
        {
            get => default;
            set
            {
            }
        }
    }
}