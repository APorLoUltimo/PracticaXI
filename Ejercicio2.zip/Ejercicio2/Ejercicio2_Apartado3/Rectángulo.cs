﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp1
{
    public class Rectángulo : Figura
    {
        private decimal width
        {
            get => default;
            set
            {
            }
        }

        private decimal length
        {
            get => default;
            set
            {
            }
        }
    }
}