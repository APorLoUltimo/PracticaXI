﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp1
{
    public class Rectángulo : Figura
    {
        public decimal width
        {
            get => default;
            set
            {
            }
        }

        public decimal length
        {
            get => default;
            set
            {
            }
        }
    }
}