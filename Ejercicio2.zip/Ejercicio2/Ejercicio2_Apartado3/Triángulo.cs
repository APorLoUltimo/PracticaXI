﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp1
{
    public class Triángulo : Figura
    {
        private decimal baseof
        {
            get => default;
            set
            {
            }
        }

        private decimal height
        {
            get => default;
            set
            {
            }
        }
    }
}