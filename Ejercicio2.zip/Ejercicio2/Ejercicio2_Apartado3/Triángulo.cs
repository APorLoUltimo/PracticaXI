﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp1
{
    public class Triángulo : Figura
    {
        public decimal baseof
        {
            get => default;
            set
            {
            }
        }

        public decimal height
        {
            get => default;
            set
            {
            }
        }
    }
}