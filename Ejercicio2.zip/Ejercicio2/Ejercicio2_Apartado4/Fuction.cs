﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio
{
    internal class Fuction
    {
        public static string NombreEncargado()
        {
            string entrada = "";
            Console.WriteLine("Dime el nombre del encargado");
            do
            {
                entrada=Console.ReadLine();
                if (entrada.Length < 3) Console.WriteLine("deve ser de minimo 3 letras");
            }while(entrada.Length <3);
            return entrada;
        }
        public static int NombreTelefono()
        {
            int entrada = 0;
            Console.WriteLine("Dime el numero de telefono");
            while ((!int.TryParse(Console.ReadLine(), out entrada) )|| !(entrada.ToString().Length ==9 ))
                Console.WriteLine("numero incorrecto");
            return entrada;
        }
        public static void menu()
        {
            Console.WriteLine($"1_ Alquilar juego");
            Console.WriteLine($"2_ Devolver Juego");
            Console.WriteLine($"3_ Mostrar info tienda");
            Console.WriteLine($"4_mostrar historial");
            Console.WriteLine($"0 salir");
        }
        public static  int EntradaCod()
        {
            Console.WriteLine("dime el codigo cliente");
            int entrada = 0;
            while (!Int32.TryParse(Console.ReadLine(), out entrada) || !(entrada >99) || !(entrada < 1000))
                Console.WriteLine("dato incorecto elija un numero de tres cifraa");
            return 0;
        }
    }
}
