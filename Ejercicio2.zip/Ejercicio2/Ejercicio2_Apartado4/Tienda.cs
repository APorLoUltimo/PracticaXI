﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ejercicio
{
    internal class Tienda
    {
        //atributos
        private string Encargado { get; set; }
        private int telefono { get; set; }
        private List<Juegos> Catalogo { get; set; }
        //costructor
        public Tienda() 
        { 
            Catalogo=new List<Juegos>();
        }
        public Tienda(string encargado, int telefono, List<Juegos> catalogo)
        {
            SetEncargado(encargado);
            SetTelefono(telefono);
           this.Catalogo = catalogo;
        }

        //get
        public string GetEncargado()
        {
            return this.Encargado;
        }
        public int GetTelefono()
        {
            return this.telefono;
        }
        public List<Juegos> GetCatalog()
        {
            return this.Catalogo;
        }
        // set 
        public void SetEncargado(string Encargado)
        {
            if (!String.IsNullOrEmpty(Encargado))
            {
                this.Encargado = Encargado;
            }
            else this.Encargado = "Desconosido";

        }
        public void SetTelefono(int telefono)
        {
            if (telefono==9)
            {
                this.telefono = telefono;
            }
            else this.telefono =922222222;

        }
        public void SetCatalogo(List<Juegos> catalogo)
        {
            this.Catalogo = catalogo;

        }
        //otros
        // DEVUVLVE TRU SI ENCUENTRA AL USUARIO
        public bool checkCod(int cod)
        {
            bool check = false;
            List<int> paso = new List<int>();
            Console.WriteLine(Catalogo.Count());
            foreach(Juegos juegos in this.Catalogo)
            {
                paso= juegos.GetListCodClientesAlquilaron();
                if (juegos.GetListCodClientesAlquilaron().Count>0)
                {
                    if (paso[paso.Count - 1] == cod) check = true;
                }
                
            }
            return check;
        }
        public List<Juegos>SacarNoAlquilados()
        {
            List<Juegos> juegosNoalquilados = new List<Juegos>();
            juegosNoalquilados= Catalogo.FindAll(juego => juego.GetAlquilado() == false);
            return juegosNoalquilados;
        }
        public List<Juegos> SacarAlquilados()
        {
            List<Juegos> juegosNoalquilados = new List<Juegos>();
            juegosNoalquilados = Catalogo.FindAll(juego => juego.GetAlquilado() == true);
            return juegosNoalquilados;
        }
        public bool checkEstaAlquilado(int posion)
        {
            bool check=false;
            if (this.Catalogo[posion].GetAlquilado()) check=true;
            return check;
        }
        public void alquilarjuego(int posision, int cod)
        {
            this.Catalogo[posision].SetAlquilado(true);
            this.Catalogo[posision].Addcod(cod);


        }
        public override string ToString()
        {
            string salida = "";
            salida = $"nombre del encargado:{Encargado}\n telefono:{telefono}";
            salida += $"\n juegos disponibles:";
            SacarNoAlquilados().ForEach(juego => salida += $"\n{juego}");
            salida += "\n juegos no disponibles";
            SacarAlquilados().ForEach(juego => salida += $"\n{juego}");
            return salida;
        }
        public void DevolverJuego(int cod)
        {
            Catalogo.Find(juego => juego.GetListCodClientesAlquilaron()[juego.GetListCodClientesAlquilaron().Count() - 1] == cod).SetAlquilado(false);

        }
        


    }
}
