﻿using System;
using System.Collections.Generic;
using System.Diagnostics.SymbolStore;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ejercicio
{
    internal class Juegos
    {
        //Atributos
        private string name { get; set; }
        private decimal precio { get; set; }
        private bool alquilado { get; set; }
        private List<int> listCodClientesAlquilaron { get; set; }

        /// <summary>
        /// una tienda N juegos 
        /// un juego una tienda
        /// </summary>
        internal Tienda Tienda
        {
            get => default;
            set
            {
            }
        }

        //constructor
        public Juegos()
        {
            listCodClientesAlquilaron = new List<int>();
        }
        public Juegos(string name, decimal precio)
        {
            SetName(name);
            SetPrecio(precio);
            this.alquilado = false;
            this.listCodClientesAlquilaron = new List<int>();
        }

        // get
        public string GetName()
        {
            return name;
        }
        public decimal GetPrecio()
        {
            return precio;
        }
        //devuelve false si  no esta alquilado
        public bool GetAlquilado()
        {
            return alquilado;
        }
        public List<int> GetListCodClientesAlquilaron()
        {
            return listCodClientesAlquilaron;
        }

        //set
        public void SetName(string name)
        {
            if (!String.IsNullOrEmpty(name))
            {
                this.name = name;
            }
            else this.name = "Desconosido";

        }
        public void SetPrecio(decimal precio)
        {
            decimal paso = 0;
            if (precio > 0)
            {
                this.precio = precio;
            }
            else this.precio = 1;

        }
        public void SetAlquilado(bool check)
        {
            this.alquilado = check;

        }

        public void SetListCodClientesAlquilaron(List<int> codclientelist)
        {
            this.listCodClientesAlquilaron = codclientelist;

        }
        //otros 

        public int VecesAlquilado()
        {
            return this.listCodClientesAlquilaron.Count();
        }
        public override string ToString()
        {
            string salida = "";
            salida = $"{this.name}: {this.precio}";
            if (alquilado) salida += $" alquilado";
            else salida += " disponible";
            return salida;
        }
        public void Addcod(int cod)
        {
            this.listCodClientesAlquilaron.Add(cod);
        }
        public decimal sacartotal()
        {
            decimal result=this.precio * listCodClientesAlquilaron.Count();
            return result;
        }
      

    }
}
