﻿using ejercicio;
using System.Security.Cryptography.X509Certificates;
using System.Xml;

namespace Ejercicio1
{
    //
    class Program
    {
        private static void Main(string[] args)
        {
            //dar de alta la tienda 
            // encargado 3 o mas letras 
            // telefono empieza por 922 
            string encargado = Fuction.NombreEncargado();
            int telefono= Fuction.NombreTelefono();
            List<Juegos>Catalogo= new List<Juegos>();
            Catalogo.Add(new Juegos("Zelda", 25));
            Catalogo.Add(new Juegos("Mario",20));
            Catalogo.Add(new Juegos("Chras Wandicor", 10));
            Catalogo.Add(new Juegos("Persona 3", 30));
            Tienda Tienda1 = new Tienda(encargado,telefono, Catalogo);
            int entrada = 0;
            int cod = 0;
            int entradaJuego=0;
            do
            {
                Fuction.menu();
                while(!Int32.TryParse(Console.ReadLine(), out entrada) || !(entrada>=0) || !(entrada<=4))
                    Console.WriteLine("dato incorecto elija un numero del 0 al 4");
                switch(entrada)
                {
                    case 1:
                        cod = Fuction.EntradaCod();
                        if (Tienda1.checkCod(cod)) Console.WriteLine("el usuario ya alquilo un juego");
                        else
                        {
                            int cont = 1;
                            Console.WriteLine(Tienda1.GetCatalog().Count());
                            Tienda1.SacarNoAlquilados().ForEach(juego => Console.WriteLine($"{cont++}_ {juego} "));
                            while (!Int32.TryParse(Console.ReadLine(), out entradaJuego) || !(entradaJuego > 0) ||!( entradaJuego < Tienda1.SacarNoAlquilados().Count()))
                                Console.WriteLine("entrada no valida");
                            entradaJuego--;
                            if (!(Tienda1.checkEstaAlquilado(entradaJuego))) Tienda1.alquilarjuego(entradaJuego, cod);
                            else Console.WriteLine("el juego ya esta alquilado");
                        }

                        break;
                    case 2:
                        cod = Fuction.EntradaCod();
                        if (Tienda1.checkCod(cod))
                        {
                            Tienda1.DevolverJuego(cod);
                            Console.WriteLine("jeugo devuelto");
                        }
                        else Console.WriteLine("no tienes juegos para alquilar");

                        break;
                    case 3:
                        Console.WriteLine(Tienda1.ToString());
                        break;
                    case 4:
                        int contador = 1;
                        Tienda1.GetCatalog().ForEach(juego => Console.WriteLine($"{contador++} {juego}"));
                        Console.WriteLine("dime el juego que deseas");
                        while (!Int32.TryParse(Console.ReadLine(), out entradaJuego) || !(entradaJuego > 0) || !(entradaJuego < Tienda1.GetCatalog().Count()))
                            Console.WriteLine("entrada no valida");

                        Console.WriteLine($"se a recaudado: {Tienda1.GetCatalog()[entradaJuego - 1].sacartotal()}");
                       
                        break;
                    case 0:
                        break;
                }
                Console.Clear();
            } while (entrada != 0);
        }
    }
}
