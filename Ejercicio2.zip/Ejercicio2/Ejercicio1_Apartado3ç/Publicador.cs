﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ejercicio1_Apartado3
{
    public class Publicador
    {
        public Subscriptor Subscriptor
        {
            get => default;
            set
            {
            }
        }

        public void AvisarSubscriptor()
        {
            throw new System.NotImplementedException();
        }

        public void Update()
        {
            throw new System.NotImplementedException();
        }
    }
}