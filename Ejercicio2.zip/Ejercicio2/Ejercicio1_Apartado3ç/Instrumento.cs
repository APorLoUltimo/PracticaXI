﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ejercicio1_Apartado3
{
    public abstract class Instrumento : Subscriptor
    {
        public abstract void RecogerDatos();
    }
}