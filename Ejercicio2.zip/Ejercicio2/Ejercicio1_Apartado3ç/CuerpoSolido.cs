﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ejercicio1_Apartado3
{
    public class CuerpoSolido : Publicador
    {
        private string direccion
        {
            get => default;
            set
            {
            }
        }

        private string imgpath
        {
            get => default;
            set
            {
            }
        }

        private decimal velocidad
        {
            get => default;
            set
            {
            }
        }

        private System.Collections.Generic.List<decimal> posicion
        {
            get => default;
            set
            {
            }
        }
    }
}