﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ejercicio1_Apartado3
{
    public class Subscriptor
    {
        private int id
        {
            get => default;
            set
            {
            }
        }
    }
}